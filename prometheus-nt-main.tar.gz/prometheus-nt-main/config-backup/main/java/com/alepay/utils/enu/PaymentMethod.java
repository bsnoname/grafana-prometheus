package com.alepay.utils.enu;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public enum PaymentMethod implements Serializable, Comparable<PaymentMethod> {

    VISA,
    MASTERCARD,
    JCB,
    ATM,
    UNIONPAY,
    AMERICAN_EXPRESS,
    NLTOKEN,
    ATM_ON,
    IB_ON,
    QRCODE,
    VIETQR,
    BANK_TRANSFER_ONLINE,
    BANK_TRANSFER,
    NAPAS_CREDIT,
    MPOS,
    MPOS_ATM,
    MPOS_QRCODE_BANK,
    MPOS_QRCODE_WECHAT,
    MPOS_QRCODE_VIETTELQR,
    MPOS_QRCODE_VIMOQR,
    MPOS_QRCODE_VINID,
    MPOS_QRCODE_MOMO,
    MPOS_QRCODE_SMARTPAY,
    MPOS_QRCODE_SHOPEEPAY,
    MPOS_QR247,
    VAY_MUON,
    MPOS_VISA,
    MPOS_MASTER,
    MPOS_AMEX,
    MPOS_JCB,
    MPOS_CUP,
    MPOS_DCI,
    MPOS_VISA_IN,
    MPOS_MASTER_IN,
    MPOS_AMEX_IN,
    MPOS_JCB_IN,
    MPOS_CUP_IN,
    MPOS_DCI_IN,
    MPOS_VIETQR,
    MPOS_NAPASCREDIT,
    MPOS_VAQR,
    APPLEPAY,
    APPLEPAY_VISA,
    APPLEPAY_MASTER,
    APPLEPAY_JCB,
    GOOGLEPAY,
    VISA_INTERNATIONAL,

    // Add Payment Method private MSB VA
    VA,
    MPOS_DXNEXTPAY,
    MPOS_DXNEXTPAY_ON,
    ON;

    public static Map<PaymentMethod, String> getAllPaymentMethod() {
        Map<PaymentMethod, String> mapPaymentMethod = new HashMap<>();
        List<PaymentMethod> paymentMethodsReject = new ArrayList<>();
        List<PaymentMethod> paymentMethodsAll = new LinkedList<>(Arrays.asList(values()));
        paymentMethodsReject.add(PaymentMethod.BANK_TRANSFER);
        paymentMethodsReject.add(PaymentMethod.ON);
        paymentMethodsReject.add(PaymentMethod.VIETQR);
        paymentMethodsReject.add(PaymentMethod.BANK_TRANSFER_ONLINE);

        paymentMethodsAll.removeAll(paymentMethodsReject);
        return getPaymentMethodStringMap(mapPaymentMethod, paymentMethodsAll);
    }

    public static Map<PaymentMethod, String> getAllPaymentMethodDomestic() {
        Map<PaymentMethod, String> mapPaymentMethod = new HashMap<>();
        List<PaymentMethod> paymentMethodsDomestic = new ArrayList<>();
        paymentMethodsDomestic.add(PaymentMethod.ATM);
        paymentMethodsDomestic.add(PaymentMethod.ATM_ON);
        paymentMethodsDomestic.add(PaymentMethod.IB_ON);
        paymentMethodsDomestic.add(PaymentMethod.QRCODE);
//        paymentMethodsDomestic.add(PaymentMethod.VIETQR);
        paymentMethodsDomestic.add(PaymentMethod.VA);
//        paymentMethodsDomestic.add(PaymentMethod.BANK_TRANSFER_ONLINE);
        paymentMethodsDomestic.add(PaymentMethod.NAPAS_CREDIT);

        return getPaymentMethodStringMap(mapPaymentMethod, paymentMethodsDomestic);
    }

    public static Map<PaymentMethod, String> getPaymentMethodDomesticRejectVA() {
        Map<PaymentMethod, String> mapPaymentMethod = new HashMap<>();
        List<PaymentMethod> paymentMethodsDomestic = new ArrayList<>();
        paymentMethodsDomestic.add(PaymentMethod.ATM);
        paymentMethodsDomestic.add(PaymentMethod.ATM_ON);
        paymentMethodsDomestic.add(PaymentMethod.IB_ON);
        paymentMethodsDomestic.add(PaymentMethod.QRCODE);
        paymentMethodsDomestic.add(PaymentMethod.NAPAS_CREDIT);

        return getPaymentMethodStringMap(mapPaymentMethod, paymentMethodsDomestic);
    }

    public static Map<PaymentMethod, String> getPaymentMethodInternational() {
        Map<PaymentMethod, String> mapPaymentMethod = new HashMap<>();
        List<PaymentMethod> paymentMethodsInternational = new ArrayList<>();
        paymentMethodsInternational.add(PaymentMethod.VISA);
        paymentMethodsInternational.add(PaymentMethod.MASTERCARD);
        paymentMethodsInternational.add(PaymentMethod.JCB);
        paymentMethodsInternational.add(PaymentMethod.AMERICAN_EXPRESS);
        paymentMethodsInternational.add(PaymentMethod.VISA_INTERNATIONAL);

        return getPaymentMethodStringMap(mapPaymentMethod, paymentMethodsInternational);
    }

    public static Map<PaymentMethod, String> getPaymentMethodChannelNormal() {
        Map<PaymentMethod, String> mapPaymentMethod = new HashMap<>();
        List<PaymentMethod> paymentMethodsInternational = new ArrayList<>();
        paymentMethodsInternational.add(PaymentMethod.MASTERCARD);

        return getPaymentMethodStringMap(mapPaymentMethod, paymentMethodsInternational);
    }

    public static Map<PaymentMethod, String> getAllPaymentMethodInstallment() {
        Map<PaymentMethod, String> mapPaymentMethod = new HashMap<>();
        List<PaymentMethod> paymentMethodsIns = new ArrayList<>();
        paymentMethodsIns.add(PaymentMethod.VISA);
        paymentMethodsIns.add(PaymentMethod.MASTERCARD);
        paymentMethodsIns.add(PaymentMethod.JCB);
        paymentMethodsIns.add(PaymentMethod.UNIONPAY);
        paymentMethodsIns.add(PaymentMethod.VAY_MUON);
        paymentMethodsIns.add(PaymentMethod.AMERICAN_EXPRESS);
        paymentMethodsIns.add(PaymentMethod.MPOS);
        paymentMethodsIns.add(PaymentMethod.MPOS_VISA);
        paymentMethodsIns.add(PaymentMethod.MPOS_MASTER);
        paymentMethodsIns.add(PaymentMethod.MPOS_JCB);
        paymentMethodsIns.add(PaymentMethod.MPOS_QRCODE_SMARTPAY);
        paymentMethodsIns.add(PaymentMethod.MPOS_QRCODE_SHOPEEPAY);
        paymentMethodsIns.add(PaymentMethod.MPOS_QRCODE_BANK);
        paymentMethodsIns.add(PaymentMethod.MPOS_QRCODE_WECHAT);
        paymentMethodsIns.add(PaymentMethod.MPOS_QR247);
        paymentMethodsIns.add(PaymentMethod.MPOS_VIETQR);
        paymentMethodsIns.add(PaymentMethod.MPOS_AMEX);
        paymentMethodsIns.add(PaymentMethod.MPOS_CUP);
        paymentMethodsIns.add(PaymentMethod.MPOS_DCI);
        paymentMethodsIns.add(PaymentMethod.MPOS_VISA_IN);
        paymentMethodsIns.add(PaymentMethod.MPOS_MASTER_IN);
        paymentMethodsIns.add(PaymentMethod.MPOS_AMEX_IN);
        paymentMethodsIns.add(PaymentMethod.MPOS_JCB_IN);
        paymentMethodsIns.add(PaymentMethod.MPOS_CUP_IN);
        paymentMethodsIns.add(PaymentMethod.MPOS_DCI_IN);
        paymentMethodsIns.add(PaymentMethod.MPOS_NAPASCREDIT);
        paymentMethodsIns.add(PaymentMethod.NAPAS_CREDIT);
        paymentMethodsIns.add(PaymentMethod.MPOS_DXNEXTPAY);
        paymentMethodsIns.add(PaymentMethod.MPOS_DXNEXTPAY_ON);
        paymentMethodsIns.add(PaymentMethod.MPOS_VAQR);
        paymentMethodsIns.add(PaymentMethod.VISA_INTERNATIONAL);

        return getPaymentMethodStringMap(mapPaymentMethod, paymentMethodsIns);
    }

    private static Map<PaymentMethod, String> getPaymentMethodStringMap(Map<PaymentMethod, String> mapPaymentMethod, List<PaymentMethod> paymentMethodsIns) {
        for (PaymentMethod paymentMethod : paymentMethodsIns) {
            mapPaymentMethod.put(paymentMethod, valueShow(paymentMethod));
        }
        // Sort
        mapPaymentMethod = mapPaymentMethod.entrySet().stream()
                .sorted(Comparator.comparingInt(o -> o.getKey().ordinal()))
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));
        return mapPaymentMethod;
    }

    private static String valueShow(PaymentMethod paymentMethod) {
        switch (paymentMethod) {
            case VISA:
                return "Visa";
            case MASTERCARD:
                return "MasterCard";
            case AMERICAN_EXPRESS:
                return "AMERICAN EXPRESS";
            case VAY_MUON:
                return "Vay Mượn";
            case MPOS_VISA_IN:
                return "MPOS_VISA_DOMESTIC";
            case MPOS_MASTER_IN:
                return "MPOS_MASTER_DOMESTIC";
            case MPOS_AMEX_IN:
                return "MPOS_AMEX_DOMESTIC";
            case MPOS_CUP_IN:
                return "MPOS_CUP_DOMESTIC";
            case MPOS_DCI_IN:
                return "MPOS_DCI_DOMESTIC";
            case MPOS_JCB_IN:
                return "MPOS_JCB_DOMESTIC";
            case VISA_INTERNATIONAL:
                return "Visa International";
        }
        return paymentMethod.name();
    }

    public static String valueShowCardType(PaymentMethod paymentMethod) {
        switch (paymentMethod) {
            case VISA:
                return "Thẻ VISA";
            case MASTERCARD:
                return "Thẻ MASTERCARD";
            case JCB:
                return "Thẻ JCB";
            case UNIONPAY:
                return "Thẻ UNIONPAY";
            case AMERICAN_EXPRESS:
                return "Thẻ AMEX";
            case MPOS_VISA_IN:
                return "MPOS_VISA_DOMESTIC";
            case MPOS_MASTER_IN:
                return "MPOS_MASTER_DOMESTIC";
            case MPOS_AMEX_IN:
                return "MPOS_AMEX_DOMESTIC";
            case MPOS_CUP_IN:
                return "MPOS_CUP_DOMESTIC";
            case MPOS_DCI_IN:
                return "MPOS_DCI_DOMESTIC";
            case MPOS_JCB_IN:
                return "MPOS_JCB_DOMESTIC";
//            case VIETQR:
//                return "Thanh toán VietQR";
//            case BANK_TRANSFER_ONLINE:
//                return "Chuyển khoản ngay";
            case VA:
                return "Chuyển khoản VietQR";
            case NAPAS_CREDIT:
                return "Trả góp ATM";
        }
        return paymentMethod.name();
    }


    public static PaymentMethod get(String name) {
        return PaymentMethod.valueOf(name);
    }
}
