package com.alepay.utils.enu;

import java.io.Serializable;

public enum TestEnum implements Serializable, Comparable<TestEnum> {

}
